<#
  Installs the Mike Spear Outlook signature by downloading the current copy
  from links.mikespear.com straight into %APPDATA%\Microsoft\Signatures, then
  sets it as the default for new mail and replies.

  Downloading is the point: the signature is never pasted into Outlook's
  Signatures editor, because doing that makes Word rewrite the hosted images
  as image001.png attachments, and attached images get stripped out of quoted
  replies. Push a change to the site, re-run this, done.

  Setting the default is done in the registry for the same reason. The only
  other way to do it is the Signatures dialog, and clicking OK in there with a
  signature loaded can re-save the file - the exact thing this avoids. The
  assignment itself is two plain REG_SZ values per account, so there is
  nothing clever about writing them directly.
#>

[CmdletBinding()]
param(
  # Whatever you name it here is the name Outlook shows in the Signatures list.
  [string]$Name    = 'Default Sig (mike@mikespear.com)',
  [string]$BaseUrl = 'https://links.mikespear.com',

  # Accounts whose address contains this get the signature set as default.
  [string]$AccountMatch = '@mikespear.com',

  # Install the files but leave the defaults alone.
  [switch]$NoAssign,

  # Newer Outlook builds keep signatures in the mailbox and ignore the local
  # folder. This opts back out. Not set unless asked for - it changes how
  # Outlook behaves beyond this one signature.
  [switch]$DisableRoamingSignatures,

  # Overridable so the account-matching logic can be tested against a
  # synthetic registry tree instead of a live Outlook profile.
  [string]$OfficeRoot = 'HKCU:\Software\Microsoft\Office'
)

$ErrorActionPreference = 'Stop'

function Fail($msg) {
  Write-Host ''
  Write-Host "  ** $msg" -ForegroundColor Red
  Write-Host ''
  exit 1
}

# Outlook stores most profile strings as REG_BINARY UTF-16, some as REG_SZ.
function Read-RegString($key, $valueName) {
  $v = $key.GetValue($valueName)
  if ($null -eq $v) { return '' }
  if ($v -is [byte[]]) { return ([Text.Encoding]::Unicode.GetString($v) -replace "`0", '').Trim() }
  return "$v"
}

function Get-OutlookVersionKeys($root) {
  Get-ChildItem $root -ErrorAction SilentlyContinue |
    Where-Object { $_.PSChildName -match '^\d+\.\d+$' }
}

# Walks every Outlook profile and sets the two signature values on each mail
# account matching $Match. Returns what it changed so the caller can report it.
function Set-SignatureDefault {
  param([string]$Root, [string]$SigName, [string]$Match)

  $changed = @()
  foreach ($ver in Get-OutlookVersionKeys $Root) {
    $profiles = Join-Path $ver.PSPath 'Outlook\Profiles'
    if (-not (Test-Path $profiles)) { continue }

    foreach ($prof in Get-ChildItem $profiles -ErrorAction SilentlyContinue) {
      $accounts = Join-Path $prof.PSPath '9375CFF0413111d3B88A00104B2A6676'
      if (-not (Test-Path $accounts)) { continue }

      foreach ($acct in Get-ChildItem $accounts -ErrorAction SilentlyContinue) {
        $key = Get-Item $acct.PSPath
        $id  = @((Read-RegString $key 'Account Name'), (Read-RegString $key 'Email')) |
                 Where-Object { $_ }
        if (-not ($id | Where-Object { $_ -like "*$Match*" })) { continue }

        Set-ItemProperty -Path $acct.PSPath -Name 'New Signature'           -Value $SigName -Type String
        Set-ItemProperty -Path $acct.PSPath -Name 'Reply-Forward Signature' -Value $SigName -Type String

        $changed += [pscustomobject]@{
          Profile = $prof.PSChildName
          Subkey  = $acct.PSChildName
          Account = ($id | Select-Object -First 1)
        }
      }
    }
  }
  return $changed
}

Write-Host ''
Write-Host "  Outlook signature installer" -ForegroundColor Cyan
Write-Host "  user:   $env:USERNAME"
Write-Host "  source: $BaseUrl/signature-outlook.htm"

$dest = Join-Path $env:APPDATA 'Microsoft\Signatures'
Write-Host "  dest:   $dest"
Write-Host ''

if (Get-Process -Name OUTLOOK -ErrorAction SilentlyContinue) {
  Fail 'Outlook is still running. Close it completely, then run this again.'
}

# Windows PowerShell 5.1 can still default to TLS 1.0, which the host rejects.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$tmp = Join-Path $env:TEMP ("sig-" + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tmp -Force | Out-Null

try {
  # Run straight after a push and the CDN can still be serving the pre-deploy
  # copy. The sanity check below would not catch that - a stale signature is
  # still a perfectly valid signature - so it would install silently and look
  # fine. A fresh query string per run makes the cache miss on purpose.
  $bust = [Guid]::NewGuid().ToString('N')

  foreach ($f in 'signature-outlook.htm', 'signature-outlook.txt') {
    Write-Host "  downloading $f ..."
    try {
      Invoke-WebRequest -Uri ('{0}/{1}?v={2}' -f $BaseUrl, $f, $bust) `
                        -OutFile (Join-Path $tmp $f) `
                        -Headers @{ 'Cache-Control' = 'no-cache' } `
                        -UseBasicParsing -TimeoutSec 30
    } catch {
      Fail "Could not download $f - $($_.Exception.Message)"
    }
  }

  $htmBytes = [IO.File]::ReadAllBytes((Join-Path $tmp 'signature-outlook.htm'))
  $htmText  = [Text.Encoding]::UTF8.GetString($htmBytes)

  # Guard against a 404 page, a captive portal, or a truncated transfer being
  # written over a working signature.
  if ($htmText -notmatch '_MailAutoSig' -or $htmText -notmatch 'sig-avatar-seal\.png') {
    Fail "Downloaded file does not look like the signature (got $($htmBytes.Length) bytes). Nothing was changed."
  }

  if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Path $dest -Force | Out-Null }

  # Keep one rollback copy of whatever is being replaced.
  if (Test-Path (Join-Path $dest "$Name.htm")) {
    $backup = Join-Path $dest ('Backup\' + (Get-Date -Format 'yyyy-MM-dd_HHmmss'))
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    Get-ChildItem -Path $dest -Filter "$Name.*" -File |
      Copy-Item -Destination $backup -Force
    Write-Host "  backed up the previous copy to $backup"
  }

  # The .htm is pure ASCII (the (R) and middots are numeric entities), so it
  # goes down byte for byte with no conversion to get wrong.
  [IO.File]::WriteAllBytes((Join-Path $dest "$Name.htm"), $htmBytes)

  # The .txt is the opposite case: Outlook reads it as the system ANSI codepage,
  # so the UTF-8 download has to be transcoded to windows-1252 or the (R) and
  # the middots arrive as mojibake.
  # Line endings are forced to CRLF too - Outlook can run an LF-only plain-text
  # signature together into a single line.
  $txt = [Text.Encoding]::UTF8.GetString(
           [IO.File]::ReadAllBytes((Join-Path $tmp 'signature-outlook.txt'))
         ).TrimStart([char]0xFEFF) -replace "`r`n", "`n" -replace "`n", "`r`n"
  [IO.File]::WriteAllText((Join-Path $dest "$Name.txt"), $txt,
                          [Text.Encoding]::GetEncoding(1252))

  # RTF-format mail is rare and RTF cannot link to remote images anyway, so this
  # one ships as a static file rather than being generated. Optional.
  $rtf = Join-Path $PSScriptRoot "Signatures\$Name.rtf"
  if (Test-Path $rtf) {
    Copy-Item $rtf (Join-Path $dest "$Name.rtf") -Force
  }
}
finally {
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host ''
Write-Host "  Installed '$Name'." -ForegroundColor Green

if ($NoAssign) {
  Write-Host ''
  Write-Host "  -NoAssign given, so the Outlook defaults were left alone."
} else {
  Write-Host ''
  Write-Host "  setting defaults on accounts matching '$AccountMatch' ..."
  $changed = Set-SignatureDefault -Root $OfficeRoot -SigName $Name -Match $AccountMatch

  if ($changed.Count -eq 0) {
    # No profile, a different account domain, or Outlook has never been run on
    # this PC. Not fatal - the files are installed either way.
    Write-Host ''
    Write-Host "  No Outlook account matched '$AccountMatch', so nothing was set." -ForegroundColor Yellow
    Write-Host "  Set it by hand: File > Options > Mail > Signatures..., and on the right"
    Write-Host "  set 'New messages' and 'Replies/forwards' to '$Name'."
    Write-Host "  Use the dropdowns only - do not click into the editing box."  -ForegroundColor Yellow
  } else {
    foreach ($c in $changed) {
      Write-Host ("    {0}  [{1}]  {2}" -f $c.Profile, $c.Subkey, $c.Account) -ForegroundColor Green
    }
    Write-Host ''
    Write-Host "  Default for new mail and replies is now '$Name'." -ForegroundColor Green
  }
}

# Roaming signatures: if this is on, Outlook reads signatures out of the
# mailbox and the local folder this script just wrote to is ignored.
$roamingOff = $false
foreach ($ver in Get-OutlookVersionKeys $OfficeRoot) {
  $setup = Join-Path $ver.PSPath 'Outlook\Setup'
  if ($DisableRoamingSignatures) {
    if (-not (Test-Path $setup)) { New-Item -Path $setup -Force | Out-Null }
    New-ItemProperty -Path $setup -Name 'DisableRoamingSignaturesTemporaryToggle' `
                     -Value 1 -PropertyType DWord -Force | Out-Null
    $roamingOff = $true
  } elseif ((Get-ItemProperty -Path $setup -Name 'DisableRoamingSignaturesTemporaryToggle' `
                              -ErrorAction SilentlyContinue).DisableRoamingSignaturesTemporaryToggle -eq 1) {
    $roamingOff = $true
  }
}

if ($DisableRoamingSignatures) {
  Write-Host ''
  Write-Host "  Roaming signatures disabled - Outlook will read the local folder." -ForegroundColor Green
} elseif (-not $roamingOff) {
  Write-Host ''
  Write-Host "  Note: roaming signatures are not disabled on this PC. Recent Outlook" -ForegroundColor Yellow
  Write-Host "  builds store signatures in the mailbox and ignore the local folder." -ForegroundColor Yellow
  Write-Host "  If the signature does not show up, re-run with:" -ForegroundColor Yellow
  Write-Host "      Install-Signature.cmd -DisableRoamingSignatures" -ForegroundColor Yellow
}

Write-Host ''
Write-Host '  Do NOT open it in the Signatures editor. Editing it converts the' -ForegroundColor Yellow
Write-Host '  hosted images into attachments, which is the thing this avoids.'  -ForegroundColor Yellow
Write-Host ''

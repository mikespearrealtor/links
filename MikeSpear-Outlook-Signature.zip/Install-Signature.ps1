<#
  Installs the Mike Spear Outlook signature by downloading the current copy
  from links.mikespear.com straight into %APPDATA%\Microsoft\Signatures.

  Downloading is the point: the signature is never pasted into Outlook's
  Signatures editor, because doing that makes Word rewrite the hosted images
  as image001.png attachments, and attached images get stripped out of quoted
  replies. Push a change to the site, re-run this, done.
#>

[CmdletBinding()]
param(
  # Whatever you name it here is the name Outlook shows in the Signatures list.
  [string]$Name    = 'Default Sig (mike@mikespear.com)',
  [string]$BaseUrl = 'https://links.mikespear.com'
)

$ErrorActionPreference = 'Stop'

function Fail($msg) {
  Write-Host ''
  Write-Host "  ** $msg" -ForegroundColor Red
  Write-Host ''
  exit 1
}

Write-Host ''
Write-Host "  Outlook signature installer" -ForegroundColor Cyan
Write-Host "  user:   $env:USERNAME"
Write-Host "  source: $BaseUrl/signature-outlook.htm"

$dest = Join-Path $env:APPDATA 'Microsoft\Signatures'
Write-Host "  dest:   $dest"
Write-Host ''

if (Get-Process -Name OUTLOOK -ErrorAction SilentlyContinue) {
  Fail 'Outlook is still running. Close it completely, then run this again.'
}

# Windows PowerShell 5.1 can still default to TLS 1.0, which the host rejects.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$tmp = Join-Path $env:TEMP ("sig-" + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tmp -Force | Out-Null

try {
  # Run straight after a push and the CDN can still be serving the pre-deploy
  # copy. The sanity check below would not catch that - a stale signature is
  # still a perfectly valid signature - so it would install silently and look
  # fine. A fresh query string per run makes the cache miss on purpose.
  $bust = [Guid]::NewGuid().ToString('N')

  foreach ($f in 'signature-outlook.htm', 'signature-outlook.txt') {
    Write-Host "  downloading $f ..."
    try {
      Invoke-WebRequest -Uri ('{0}/{1}?v={2}' -f $BaseUrl, $f, $bust) `
                        -OutFile (Join-Path $tmp $f) `
                        -Headers @{ 'Cache-Control' = 'no-cache' } `
                        -UseBasicParsing -TimeoutSec 30
    } catch {
      Fail "Could not download $f - $($_.Exception.Message)"
    }
  }

  $htmBytes = [IO.File]::ReadAllBytes((Join-Path $tmp 'signature-outlook.htm'))
  $htmText  = [Text.Encoding]::UTF8.GetString($htmBytes)

  # Guard against a 404 page, a captive portal, or a truncated transfer being
  # written over a working signature.
  if ($htmText -notmatch '_MailAutoSig' -or $htmText -notmatch 'sig-avatar-seal\.png') {
    Fail "Downloaded file does not look like the signature (got $($htmBytes.Length) bytes). Nothing was changed."
  }

  if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Path $dest -Force | Out-Null }

  # Keep one rollback copy of whatever is being replaced.
  if (Test-Path (Join-Path $dest "$Name.htm")) {
    $backup = Join-Path $dest ('Backup\' + (Get-Date -Format 'yyyy-MM-dd_HHmmss'))
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    Get-ChildItem -Path $dest -Filter "$Name.*" -File |
      Copy-Item -Destination $backup -Force
    Write-Host "  backed up the previous copy to $backup"
  }

  # The .htm is pure ASCII (the (R) and middots are numeric entities), so it
  # goes down byte for byte with no conversion to get wrong.
  [IO.File]::WriteAllBytes((Join-Path $dest "$Name.htm"), $htmBytes)

  # The .txt is the opposite case: Outlook reads it as the system ANSI codepage,
  # so the UTF-8 download has to be transcoded to windows-1252 or the (R) and
  # the middots arrive as mojibake.
  # Line endings are forced to CRLF too - Outlook can run an LF-only plain-text
  # signature together into a single line.
  $txt = [Text.Encoding]::UTF8.GetString(
           [IO.File]::ReadAllBytes((Join-Path $tmp 'signature-outlook.txt'))
         ).TrimStart([char]0xFEFF) -replace "`r`n", "`n" -replace "`n", "`r`n"
  [IO.File]::WriteAllText((Join-Path $dest "$Name.txt"), $txt,
                          [Text.Encoding]::GetEncoding(1252))

  # RTF-format mail is rare and RTF cannot link to remote images anyway, so this
  # one ships as a static file rather than being generated. Optional.
  $rtf = Join-Path $PSScriptRoot "Signatures\$Name.rtf"
  if (Test-Path $rtf) {
    Copy-Item $rtf (Join-Path $dest "$Name.rtf") -Force
  }
}
finally {
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host ''
Write-Host "  Installed '$Name'." -ForegroundColor Green
Write-Host ''
Write-Host '  Last step, in Outlook:'
Write-Host '     File > Options > Mail > Signatures...'
Write-Host "     set 'New messages' and 'Replies/forwards' to '$Name', then OK."
Write-Host ''
Write-Host '  Do NOT click into the big editing box and do not retype or re-paste' -ForegroundColor Yellow
Write-Host '  anything there. Editing it converts the hosted images into' -ForegroundColor Yellow
Write-Host '  attachments, which is the thing this whole setup avoids.' -ForegroundColor Yellow
Write-Host ''

Mike Spear - Outlook signature installer
========================================

WHAT THIS IS
  A small installer that pulls the current signature from links.mikespear.com
  and writes it into %APPDATA%\Microsoft\Signatures on whatever PC you run it
  on, then sets it as the default for new mail and replies. It does not carry
  a copy of the signature - it fetches one each run, so it cannot go stale.

  The images in the signature are linked to https://links.mikespear.com/, not
  embedded. That is deliberate: embedded images get stripped out of quoted
  replies and show up as <image001.png> placeholders.

  Outlook's Signatures dialog re-embeds images the moment you edit and save the
  signature there. So the signature is installed by dropping the file into
  place, never by pasting into that editor - and the default is set by writing
  the two registry values Outlook keeps per account, so you never have to open
  that dialog at all.

HOW TO INSTALL ON ANOTHER PC
  1. Close Outlook completely.
  2. Copy this folder to the PC (USB stick, OneDrive, whatever).
  3. Double-click Install-Signature.cmd. It needs an internet connection.
  4. Start Outlook. Nothing else to do - it prints which accounts it set.

  If it reports that no account matched, Outlook has either never been run on
  that PC or the mailbox is on a different domain. Set it by hand in that case:
  File > Options > Mail > Signatures..., and on the right set "New messages"
  and "Replies/forwards". Use the dropdowns only; typing in the editing box is
  what breaks the images.

IF THE SIGNATURE DOES NOT APPEAR
  Recent Outlook builds store signatures in the mailbox ("roaming signatures")
  and ignore the local folder entirely. The installer warns when this is the
  case. To opt out:

    Install-Signature.cmd -DisableRoamingSignatures

  Then restart Outlook. This is a machine-wide Outlook behaviour change, which
  is why it is not done unless you ask for it.

MANUAL INSTALL (no scripts)
  1. Close Outlook.
  2. In a browser, save both of these - use Save Page As / Save Link As, and
     keep the exact filenames:
       https://links.mikespear.com/signature-outlook.htm
       https://links.mikespear.com/signature-outlook.txt
  3. Press Win+R, paste:  %APPDATA%\Microsoft\Signatures
  4. Move the two files there and rename them to:
       Default Sig (mike@mikespear.com).htm
       Default Sig (mike@mikespear.com).txt
  5. Start Outlook and set the dropdowns as above.

  The .htm is pure ASCII so it survives any save path. The .txt contains (R)
  and dot separators - if they come out as garbage, that is an encoding issue
  and the installer script handles it properly; use that instead.

UPDATING LATER
  Edit signature-outlook.htm in the links repo, push, then re-run the
  installer on each PC. Image-only changes (swapping a sig-*.png on the site)
  need no reinstall at all - they update everywhere on their own.

OPTIONS
  Install-Signature.cmd -Name "Some Other Name"
      Installs under a different signature name.
  Install-Signature.cmd -BaseUrl "https://staging.example.com"
      Pulls from somewhere else, for testing.
  Install-Signature.cmd -AccountMatch "@example.com"
      Which accounts get it set as default. Substring match against the
      account name and address. Defaults to @mikespear.com.
  Install-Signature.cmd -NoAssign
      Install the files but leave the Outlook defaults alone.
  Install-Signature.cmd -DisableRoamingSignatures
      See above.

REQUIREMENTS / GOTCHAS
  - Classic Outlook for Windows only. The "new Outlook" and Outlook on the web
    store signatures in the cloud and will re-embed the images - this method
    does not work there.
  - Outlook must be closed while this runs. It refuses to start otherwise,
    because Outlook rewrites the profile registry keys as it exits.
  - The signature name Outlook shows is just the filename. Use -Name to change
    it, and keep the .htm and .txt named identically.
  - The default is set on every matching account in every profile on the PC,
    which is usually what you want if you keep a spare profile around.
  - Recipients' mail clients may block linked images until they click
    "download pictures". That is the trade-off for surviving reply chains.
  - Signatures\...rtf is a frozen static copy, only used for RTF-format mail,
    which is rare. It is optional - delete it and nothing breaks.
  - Anything replaced is backed up to
    %APPDATA%\Microsoft\Signatures\Backup\<timestamp>\

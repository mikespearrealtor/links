Mike Spear - Outlook signature installer
========================================

WHAT THIS IS
  A small installer that pulls the current signature from links.mikespear.com
  and writes it into %APPDATA%\Microsoft\Signatures on whatever PC you run it
  on. It does not carry a copy of the signature - it fetches one each run, so
  it cannot go stale.

  The images in the signature are linked to https://links.mikespear.com/, not
  embedded. That is deliberate: embedded images get stripped out of quoted
  replies and show up as <image001.png> placeholders.

  Outlook's Signatures dialog re-embeds images the moment you edit and save the
  signature there. So the signature is installed by dropping the file into
  place, never by pasting into that editor.

HOW TO INSTALL ON ANOTHER PC
  1. Close Outlook completely.
  2. Copy this folder to the PC (USB stick, OneDrive, whatever).
  3. Double-click Install-Signature.cmd. It needs an internet connection.
  4. Open Outlook: File > Options > Mail > Signatures...
     On the right, set "New messages" and "Replies/forwards" to
     "Default Sig (mike@mikespear.com)". Click OK.

  Do not click into the signature editing box. Selecting it in the dropdowns
  is safe; typing in the box is not.

MANUAL INSTALL (no scripts)
  1. Close Outlook.
  2. In a browser, save both of these - use Save Page As / Save Link As, and
     keep the exact filenames:
       https://links.mikespear.com/signature-outlook.htm
       https://links.mikespear.com/signature-outlook.txt
  3. Press Win+R, paste:  %APPDATA%\Microsoft\Signatures
  4. Move the two files there and rename them to:
       Default Sig (mike@mikespear.com).htm
       Default Sig (mike@mikespear.com).txt
  5. Start Outlook and set the dropdowns as above.

  The .htm is pure ASCII so it survives any save path. The .txt contains (R)
  and dot separators - if they come out as garbage, that is an encoding issue
  and the installer script handles it properly; use that instead.

UPDATING LATER
  Edit signature-outlook.htm in the links repo, push, then re-run the
  installer on each PC. Image-only changes (swapping a sig-*.png on the site)
  need no reinstall at all - they update everywhere on their own.

OPTIONS
  Install-Signature.cmd -Name "Some Other Name"
      Installs under a different signature name.
  Install-Signature.cmd -BaseUrl "https://staging.example.com"
      Pulls from somewhere else, for testing.

REQUIREMENTS / GOTCHAS
  - Classic Outlook for Windows only. The "new Outlook" and Outlook on the web
    store signatures in the cloud and will re-embed the images - this method
    does not work there.
  - The signature name Outlook shows is just the filename. Use -Name to change
    it, and keep the .htm and .txt named identically.
  - Recipients' mail clients may block linked images until they click
    "download pictures". That is the trade-off for surviving reply chains.
  - Signatures\...rtf is a frozen static copy, only used for RTF-format mail,
    which is rare. It is optional - delete it and nothing breaks.
  - Anything replaced is backed up to
    %APPDATA%\Microsoft\Signatures\Backup\<timestamp>\

@echo off
rem Thin launcher. All the work is in Install-Signature.ps1 - the .cmd exists
rem only so this is a double-click, and so ExecutionPolicy cannot block it.
title Install Mike Spear Outlook Signature

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Signature.ps1" %*

echo.
pause
